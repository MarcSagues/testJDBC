import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;


public class Search extends JDialog {


    public Search(Connection c) {


    }

}
